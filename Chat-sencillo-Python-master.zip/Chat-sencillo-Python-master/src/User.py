import User
"""
Clase User
@author: Sandra del Mar Soto Corderi
"""

class User:
    """
    La clase User crea objetos que guardan el nombre, estado y el socket del cliente.
    """
    def __init__(self, socket):
        """
        Construye un objeto de tipo "User".

        :param name: El nombre con el que se identificó el cliente
        :param socket: El socket donde se guarda la conexión
        :param status: El estado que puede ser activo, ocupado o lejos
        """
        self.socket = socket
        self.name = ''
        self.status = ''

    def make_user(socket):
        """
        Crea un objeto de tipo User
        :param socket: El socket donde se guarda la conexión
        :return: regresa un objeto tipo User
        """
        user = User(socket)
        return user
