# -*- coding: utf-8 -*-

"""
Módulo que tiene las implementaciones de todos los eventos que tiene el chat

"""
import sys
import os
from User import User
from ChatRoom import ChatRoom

#LISTA DE USUARIOS Y LISTA DE CUARTOS DE CHAT
logged_in_users = []
chat_rooms = []


def identify(user, command):
    """
    Método que identifica al usuario

    :param user: El objeto tipo user que se va a modificar
    :param command: El nombre que se asignará
    :return boolean: Si se logró identificar correctamnete o no
    """
    strname = command[1]
    name_taken = False
    for user_logged in logged_in_users:
        if(strname == getattr(user_logged, 'name')):
            name_taken = True
            message = '101_...NOMBRE ' + strname + ' YA ESTÁ EN USO\n'
            getattr(user, 'socket').sendall(message.encode())
            return False
    if(not name_taken):
        setattr(user, 'name', strname)
        logged_in_users.append(user)
        message = '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO ' + strname + '\n'
        getattr(user, 'socket').sendall(message.encode())
        return True


def status(user, command):
    """
    Método que cambia el estado del usuario

    :param user: El objeto tipo user que se va a modificar
    :param command: El nuevo estado
    """
    stat = command[1]
    correct = False
    if(stat == 'AWAY'):
        setattr(user, 'status', command[1])
        correct = True
    elif(stat == 'BUSY'):
        setattr(user, 'status', command[1])
        correct = True
    elif(stat == 'ACTIVE'):
        setattr(user, 'status', command[1])
        correct = True
    else:
        message = '103_...ESTADO INVALIDO\n ...POSIBLES ESTADOS SON: ACTIVE, AWAY, BUSY\n'
        getattr(user, 'socket').sendall(message.encode())
        correct = False
    if(correct):
        message ="104_" + getattr(user, 'name') + '-' + getattr(user, 'status')
        for user_logged in logged_in_users:
            if (getattr(user_logged, 'name') != getattr(user, 'name')):
                getattr(user_logged, 'socket').sendall(message.encode())


def users(user):
    """
    Método para devolver la lista de usuarios

    :param user: El objeto tipo user que se va a ignorar para dar los usuarios
    """
    other_users = '105_'
    for user_logged in logged_in_users:
        other_users += getattr(user_logged, 'name') + ' '
    getattr(user, 'socket').sendall(other_users.encode())


def message(user, command):
    """
    Método para enviar mensaje privado

    :param user: El objeto tipo user que se va a obtener información
    :param command: El mensaje privado y el destinatario
    """
    message = "106_" + getattr(user, 'name') + ': '
    receiver = command[1]
    for word in command[2:]:
        message += word + ' '
    receiver_is_logged_in = False
    for user_logged in logged_in_users:
        if (getattr(user_logged, 'name') == receiver):
            getattr(user_logged, 'socket').sendall(message.encode())        #Send Message to a private user
            receiver_is_logged_in = True
            sent = '107_...MENSAJE ENVIADO'
            getattr(user, 'socket').sendall(sent.encode())
    if (not receiver_is_logged_in):
        message_not_log ="108_"+ receiver + ' no está conectado. '
        getattr(user, 'socket').sendall(message_not_log.encode())     #If user is not online


def public_message(user, command):
    """
    Método para devolver mensaje público

    :param user: El objeto tipo user que se va a ignorar para el mensaje
    :param command: El mensaje público
    """
    message ="109_"+getattr(user, 'name') + ': '
    for word in command[1:]:
        message += word + ' '
    for user_logged in logged_in_users:
        if (getattr(user_logged, 'name') != getattr(user, 'name')):
            getattr(user_logged, 'socket').sendall(message.encode())
    sent = '110_...MENSAJE ENVIADO'
    getattr(user, 'socket').sendall(sent.encode())

"""
Método que revisa si un usuario existe
"""
def is_user(user):
    for user_logged in logged_in_users:
        if (getattr(user_logged, 'name') == user):
            return user_logged
    return None


def create_chat_room(user, command):
    """
    Método para crear un cuarto de chat

    :param user: El objeto tipo user que será el dueño del chatroom
    :param command: El nombre del chatroom
    """
    name = command[1]
    original_name = False
    for chat_room in chat_rooms:
        if(getattr(chat_room, 'name') == name):
            original_name = True
            message = '111_...NOMBRE DEL CUARTO EN USO\n'
            getattr(user, 'socket').sendall(message.encode())
            break
    if(not original_name):
        room = ChatRoom.create_room(name, user)
        chat_rooms.append(room)
        message = '112_...CUARTO DE CHAT CREADO\n'
        getattr(user, 'socket').sendall(message.encode())

def invite(user, command):
    """
    Método para invitar usuarios a un chat room

    :param user: El objeto tipo user que será el dueño del chat
    :param command: El nombre del chatroom y los invitados
    """
    try:
        is_chat_room = False
        strname = command[1]
        for chat_room in chat_rooms:
            if (strname == getattr(chat_room, 'name')):
                is_chat_room = True
                if(user == getattr(chat_room, 'owner')):
                    invitations = getattr(chat_room, 'invited')
                    for user_to_invite in command[2:]:
                        objuser_invite = is_user(user_to_invite)
                        if(objuser_invite != None):
                            invitations.append(objuser_invite)
                            message_sender = '113_...INVITACIÓN ENVIADA A ' + user_to_invite
                            getattr(user, 'socket').sendall(message_sender.encode())
                            message = '114_...INVITACIÓN PARA UNIRTE A ' + getattr(chat_room, 'name') + ' POR ' + getattr(user, 'name')
                            getattr(objuser_invite, 'socket').sendall(message.encode())
                            setattr(chat_room, 'invited', invitations)
                        else:
                            message_sender = '115_USUARIO NO ENCONTRADO'
                            getattr(user, 'socket').sendall(message_sender.encode())
                else:
                    message = '116_...NO ERES EL DUEÑO DEL CUARTO\n'
                    getattr(user, 'socket').sendall(message.encode())
        if(not is_chat_room):
            message = '117_...EL CUARTO NO EXISTE\n'
            getattr(user, 'socket').sendall(message.encode())
    except Exception as ex:
        template = 'An exception of type {0} occurred. Arguments:\n{1!r}'
        message = template.format(type(ex).__name__, ex.args)
        print(message)

"""
Método para saber si el usuario fue invitado a un cuarto de chat
"""
def is_invited(user, chat_room):
    was_invited = False
    invited_members = getattr(chat_room, 'invited')
    for member in invited_members:
        if (getattr(user, 'name') == getattr(member, 'name')):
            was_invited = True
    return was_invited


def join_room(user, command):
    """
    Método para unirse a una sala de chat

    :param user: El objeto tipo user que querrá unirse al chatroom
    :param command: El nombre del chatroom
    """
    try:
        is_chat_room = False
        strname = command[1]
        for chat_room in chat_rooms:
            if (strname == getattr(chat_room, 'name')):
                is_chat_room = True
                if(is_invited(user, chat_room)):
                    is_valid_join = True
                    room_members = getattr(chat_room, 'joined')
                    room_members.append(user)
                    setattr(chat_room, 'joined', room_members)
                    message_sender = '118_TE HAS UNIDO AL CUARTO: ' + strname
                    getattr(user, 'socket').sendall(message_sender.encode())
                else:
                    message_sender = '119_NO ESTÁS INVITADO AL CUARTO' + strname
                    getattr(user, 'socket').sendall(message_sender.encode())
        if(not is_chat_room):
            message = '120_...CUARTO NO EXISTE\n'
            getattr(user, 'socket').sendall(message.encode())
    except Exception as ex:
        template = 'An exception of type {0} occurred. Arguments:\n{1!r}'
        message = template.format(type(ex).__name__, ex.args)
        print(message)

"""
Método para ver si el usuario se ha unido al cuarto de chat
"""
def has_joined(user, chat_room):
    has_joined = False
    joined_members = getattr(chat_room, 'joined')
    for member in joined_members:
        if (getattr(user, 'name') == getattr(member, 'name')):
            has_joined = True
    return has_joined

"""
Método que revisa si un usuario existe
"""
def is_connected(user):
    for user_logged in logged_in_users:
        if (user == user_logged):
            return True
    return False

def room_message(user, command):
    """
    Método para mandar mensajes a un cuarto de chat

    :param user: El objeto tipo user que mandará un mensaje al chatroom
    :param command: El nombre del chatroom y el contenido del mensaje
    """
    try:
        is_chat_room = False
        is_valid_join = False
        name = command[1]
        for chat_room in chat_rooms:
            if (name == getattr(chat_room, 'name')):
                is_chat_room = True
                if(has_joined(user, chat_room)):
                    is_valid_join = True
                    room_members = getattr(chat_room, 'joined')
                    for user_joined in room_members:
                        if(is_connected(user_joined)):
                            message = "121_" + getattr(user, 'name') + ': '
                            for word in command[2:]:
                                message += word + ' '
                            getattr(user_joined, 'socket').sendall(message.encode())
                    sent = '122_...MENSAJE ENVIADO'
                    getattr(user, 'socket').sendall(sent.encode())
                else:
                    message_sender = '123_NO ERES PARTE DEL CUARTO'
                    getattr(user, 'socket').sendall(message_sender.encode())
        if(not is_chat_room):
            message = '124_...EL CUARTO NO EXISTE\n'
            getattr(user, 'socket').sendall(message.encode())
    except Exception as ex:
        template = 'An exception of type {0} occurred. Arguments:\n{1!r}'
        message = template.format(type(ex).__name__, ex.args)
        print(message)

def disconnect(user):
    """
    Método para desconectarse

    :param user: El objeto tipo user que desconectará del chat
    """
    if((len(logged_in_users) > 0) and (getattr(user, 'name') != '')):
        logged_in_users.remove(user)
    message = '125_DISCONNECT'
    getattr(user, 'socket').sendall(message.encode())
