import CommandsChat
"""
Clase que tiene una enumeración de los eventos que tiene el chat

"""
import enum

class CommandsChat(enum.Enum):
    """
    Comandos del protocólo que serán usados en el chat
    """
    IDENTIFY = 'IDENTIFY username'
    STATUS = 'STATUS userStatus = {ACTIVE, AWAY, BUSY}'
    USERS = 'USERS'
    MESSAGE = 'MESSAGE username messageContent'
    PUBLICMESSAGE = 'PUBLICMESSAGE messageContent'
    CREATEROOM = 'CREATEROOM roomname'
    INVITE = 'INVITE roomname user1 user2'
    JOINROOM = 'JOINROOM roomname'
    ROOMESSAGE = 'ROOMESSAGE roomname messageContent'
    DISCONNECT = 'DISCONNECT'

    def menu(self):
        """
        Da el menu al usuario
        :return: regresa una String de todos los comandos del chat
        """
        s = CommandsChat.IDENTIFY.value + '\n' + CommandsChat.STATUS.value + '\n'
        s+= CommandsChat.MESSAGE.value + '\n' + CommandsChat.PUBLICMESSAGE.value + '\n'
        s+= CommandsChat.CREATEROOM.value + '\n' + CommandsChat.INVITE.value + '\n'
        s+= CommandsChat.JOINROOM.value + '\n' + CommandsChat.ROOMESSAGE.value + '\n'
        s+= CommandsChat.DISCONNECT.value + '\n'
        return s
