"""
Módulo que contien los métodos del cliente

"""
import socket

buffer_size = 2048
connected = False

def send_to_server(sock, mensaje):
    """
    Método que envía al servidor mensajes
    param: el socket y el mensaje
    """
    try:
        sock.sendall(mensaje.encode())
        return (1)
    except:
        return (0)

def response_Server(sock):
    """
    Método que envía al servidor mensajes
    param: socket que recibe
    """
    try:
        response = sock.recv(buffer_size)
        msg = response.decode()
        if(msg == 'DISCONNECT'):
            connected = False
            sock.close()
        return (1, msg)
    except:
        return (0, 'DISCONNECT')

def client_chat(ip, puerto):
    """
    Método que envía al servidor mensajes
    param: la ip y el puerto
    """
    sock=None
    try:
        try:
            server_IP_addr = ip
            if server_IP_addr == None or server_IP_addr == "":
                raise ValueError
            port = puerto
            server_port = int(port)
        except:
            return (0,sock,"Not valid IP_Adress and Port")
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((server_IP_addr,server_port))
            connected = True
        except(OSError):
            connected = False
            return (0, sock, "Connection Error")
        return (1, sock, "Conexion Exitosa")

    except(KeyboardInterrupt):
        return (0, sock, 'DISCONNECT')
