# -*- coding: utf-8 -*-

"""
Módulo que contien los métodos del cliente para la terminal

"""
from socket import socket, AF_INET, SOCK_STREAM
from sys import argv, stdout, exit
from threading import Thread
import os

buffer_size = 2048
connected = False

def send_to_server(sock, server_IP):
    """
    Método que envía al servidor mensajes

    :param sock: El socket del cliente
    :param server_IP: La IP del servidor
    """
    try:
        bloop_send = True
        while bloop_send:
            msg = input()
            msg += "\n"
            sock.sendall(msg.encode())
    except:
        bloop_send = False
        exit(1)


def recv_from_server(sock, server_IP):
    """
    Método que recibe mensajes del servidor

    :param sock: El socket del cliente
    :param server_IP: La IP del servidor
    """


    try:
        while connected:
            response = sock.recv(buffer_size)

            try:
                msg = response.decode()
            except(UnicodeDecodeError):
                print ('Message could not be decoded')

            msg = response.decode()
            if(msg == 'DISCONNECT'):
                connected = False
                sock.close()
                exit(-1)
            else:
                print (msg)
    except(SystemExit):
        connected = False
        print ('\nBye')
        exit(-1)



def main(argv):
    """
    Método main del cliente

    :param argv: Lo que lee de la terminal
    """
    try:
        try:
            print("IP_Adress:")
            server_IP_addr = input()
            if server_IP_addr == None or server_IP_addr == "":
                raise ValueError
            print("Port:")
            port = input()
            server_port = int(port)
        except:
            print("Not valid IP_Adress and Port")
            exit(-1)

        try:
            sock = socket(AF_INET, SOCK_STREAM)
            sock.connect((server_IP_addr,server_port))
            connected = True
        except(OSError):
            connected = False
            print("Connection Error")
            exit(-1)

        send_thread = Thread(target=send_to_server, args=(sock, server_IP_addr))
        send_thread.daemon = True
        send_thread.start()

        try:
            while connected:
                response = sock.recv(buffer_size)
                msg = response.decode()
                if(msg == 'DISCONNECT'):
                    connected = False
                    sock.close()
                    exit(-1)
                else:
                    print (msg)
        except(SystemExit):
            connected = False
            print ('\nBye')
            exit(-1)

    except(KeyboardInterrupt):
        print ('\nClient shut down')
        exit(-1)

if __name__ == '__main__':
	main(argv)
