# -*- coding: utf-8 -*-

"""
Clase que prueba al servidor

"""
import unittest
import socket
import sys
import time
import threading
sys.path.append("..")

import Server

class TestServer(unittest.TestCase):

    #Servidor inicializado
    thread = threading.Thread(target=Server.main)
    thread.start()

    def conecta_cliente(self):
        cliente_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        cliente_socket.connect(('127.0.0.1', 1234))
        return cliente_socket

    def test_pide_identify(self):
        cliente_socket = self.conecta_cliente()
        cliente_socket.send('STATUS ACTIVE'.encode())
        self.assertEqual(cliente_socket.recv(2048).decode(), 'TE DEBES IDENTIFICAR PRIMERO')
        cliente_socket.send('MESSAGE usuario hola '.encode())
        self.assertEqual(cliente_socket.recv(2048).decode(), 'TE DEBES IDENTIFICAR PRIMERO')
        cliente_socket.send('USERS'.encode())
        self.assertEqual(cliente_socket.recv(2048).decode(), 'TE DEBES IDENTIFICAR PRIMERO')
        cliente_socket.send('PUBLICMESSAGE hola'.encode())
        self.assertEqual(cliente_socket.recv(2048).decode(), 'TE DEBES IDENTIFICAR PRIMERO')
        cliente_socket.send('CREATEROOM cuarto'.encode())
        self.assertEqual(cliente_socket.recv(2048).decode(), 'TE DEBES IDENTIFICAR PRIMERO')
        cliente_socket.send('INVITE cuarto usuario'.encode())
        self.assertEqual(cliente_socket.recv(2048).decode(), 'TE DEBES IDENTIFICAR PRIMERO')
        cliente_socket.send('JOINROOM cuarto'.encode())
        self.assertEqual(cliente_socket.recv(2048).decode(), 'TE DEBES IDENTIFICAR PRIMERO')
        cliente_socket.send('ROOMESSAGE cuarto hola'.encode())
        self.assertEqual(cliente_socket.recv(2048).decode(), 'TE DEBES IDENTIFICAR PRIMERO')
        cliente_socket.send('DISCONNECT'.encode())

    def test_identify(self):
        cliente_socket = self.conecta_cliente()
        cliente_socket.send('IDENTIFY alma'.encode())
        self.assertEqual(cliente_socket.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO  \n')
        cliente_socket.send('IDENTIFY alma'.encode())
        self.assertEqual(cliente_socket.recv(2048).decode(), 'YA TE HAS IDENTIFICADO\n')
        cliente_socket.send('DISCONNECT'.encode())

    def test_status(self):
        usuario1 = self.conecta_cliente()
        usuario1.send('IDENTIFY elizabeth'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO hermo@\n')
        usuario1.send('STATUS ACTIVE'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '')
        usuario1.send('DISCONNECT'.encode())

    def test_message(self):
        usuario1 = self.conecta_cliente()
        usuario1.send('IDENTIFY sandy'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO hermo@\n')
        usuario2 = self.conecta_cliente()
        usuario2.send('IDENTIFY maria'.encode())
        self.assertEqual(usuario2.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO hermo@\n')
        usuario1.send('MESSAGE maria hola maria'.encode())
        self.assertEqual(usuario2.recv(2048).decode(), '106_sandy: hola hermo@ ')
        usuario2.send('MESSAGE susan hola susan'.encode())
        self.assertEqual(usuario2.recv(2048).decode(), '108_susan no está conectado. ')
        usuario1.send('DISCONNECT'.encode())
        usuario2.send('DISCONNECT'.encode())

    def test_publicmessage(self):
        usuario1 = self.conecta_cliente()
        usuario1.send('IDENTIFY erick'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO hermo@k\n')
        usuario1.send('PUBLICMESSAGE hola todos :D'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '')
        usuario1.send('DISCONNECT'.encode())

    def test_createroom(self):
        usuario1 = self.conecta_cliente()
        usuario1.send('IDENTIFY mariela'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO hermo@\n')
        usuario1.send('CREATEROOM sala'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '112_...CUARTO DE CHAT CREADO\n')
        usuario1.send('DISCONNECT'.encode())

    def test_invite(self):
        usuario1 = self.conecta_cliente()
        usuario1.send('IDENTIFY raul'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO hermo@l\n')
        usuario2 = self.conecta_cliente()
        usuario2.send('IDENTIFY aldo'.encode())
        self.assertEqual(usuario2.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO hermo@\n')
        usuario1.send('CREATEROOM norte'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '112_...CUARTO DE CHAT CREADO\n')
        usuario1.send('INVITE norte aldo'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '113_...INVITACIÓN ENVIADA A aldo')
        self.assertEqual(usuario2.recv(2048).decode(), '114_...INVITACIÓN PARA UNIRTE A norte POR hermo@')

    def test_joinroom(self):
        usuario1 = self.conecta_cliente()
        usuario1.send('IDENTIFY liam'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO hermo@\n')
        usuario2 = self.conecta_cliente()
        usuario2.send('IDENTIFY louis'.encode())
        self.assertEqual(usuario2.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO hermo@\n')
        usuario1.send('CREATEROOM oned'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '112_...CUARTO DE CHAT CREADO\n')
        usuario1.send('INVITE oned louis'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '113_...INVITACIÓN ENVIADA A louis')
        self.assertEqual(usuario2.recv(2048).decode(), '114_...INVITACIÓN PARA UNIRTE A oned POR hermo@')
        usuario2.send('JOINROOM oned'.encode())
        self.assertEqual(usuario2.recv(2048).decode(), '118_TE HAS UNIDO AL CUARTO: oned')
        usuario1.send('DISCONNECT'.encode())
        usuario2.send('DISCONNECT'.encode())

    def test_roomessage(self):
        usuario1 = self.conecta_cliente()
        usuario1.send('IDENTIFY a'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO a\n')
        usuario2 = self.conecta_cliente()
        usuario2.send('IDENTIFY b'.encode())
        self.assertEqual(usuario2.recv(2048).decode(), '102_...IDENTIFICACIÓN CORRECTA. BIENVENIDO b\n')
        usuario1.send('CREATEROOM c'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '112_...CUARTO DE CHAT CREADO\n')
        usuario1.send('INVITE c b'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '113_...INVITACIÓN ENVIADA A b')
        self.assertEqual(usuario2.recv(2048).decode(), '114_...INVITACIÓN PARA UNIRTE A c POR a')
        usuario2.send('JOINROOM c'.encode())
        self.assertEqual(usuario2.recv(2048).decode(), '118_TE HAS UNIDO AL CUARTO: c')
        usuario2.send('ROOMESSAGE c hola'.encode())
        self.assertEqual(usuario2.recv(2048).decode(), '121_b: hola ')
        usuario1.send('DISCONNECT'.encode())
        usuario2.send('DISCONNECT'.encode())

    def test_disconnect(self):
        usuario1 = self.conecta_cliente()
        usuario1.send('DISCONNECT'.encode())
        self.assertEqual(usuario1.recv(2048).decode(), '125_DISCONNECT')
        usuario1.send('DISCONNECT'.encode())


if __name__ == '__main__':
    unittest.main(warnings='ignore')
