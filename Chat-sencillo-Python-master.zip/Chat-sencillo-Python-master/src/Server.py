 # -*- coding: utf-8 -*-

"""
Módulo que tiene la implementación del servidor

"""
import socket
import re
import logging
from sys import argv
from sys import stdout
import sys
from threading import Thread, Timer
import datetime
import os
import os.path
import enum
import random

from CommandsChat import CommandsChat
import CommandsMethods as CommandsMethods
from User import User
from ChatRoom import ChatRoom

logging.basicConfig(level=logging.INFO, filename='chatserver.log', format='[%(levelname)s] %(asctime)s %(threadName)s %(message)s', )

buffer_size = 2048
host = '0.0.0.0'                            #Permite ips de todo tipo
backlog = 10                                #Conexiones en fila
time_expire = 30 * 60                       #Tiempo de expiración del cliente

connected_clients=[]                        #Clientes conectados

def client_timeout(client, client_ip_and_port=1234):
    """
    Método que cierra la conexión del cliente si está inactivo por 30 minutos

    :param client: El cliente cuya conexión se va a cerrar
    """
    message = 'Tu sesión ha terminado debido a inactividad. '
    getattr(client, 'socket').sendall(message.encode())
    getattr(client, 'socket').close()
    connected_clients.remove(client)
    client_exit(client_ip_and_port)
    CommandsMethods.disconnect(client)

def client_exit(client_ip_and_port):
    """
    Método que cierra la conexión del cliente

    :param client: El cliente cuya conexión se va a cerrar
    :param client_ip_and_port: La IP y Puerto del cliente
    """
    print ('Cliente en %s : %s se ha desconectado' %(client_ip_and_port[0], client_ip_and_port[1]))
    logging.info("Cliente en IP {} & Puerto {} se desconectó".format(client_ip_and_port[0], client_ip_and_port[1]))
    stdout.flush()

def prompt_commands(client, client_ip_and_port, client_sock, has_identified):
    """
    Método que ejecuta y muestra los comandos del chat al usuario

    :param client: El cliente que estará usando el chat
    :param client_ip_and_port: La IP y Puerto del cliente
    :param has_identified: Bandera si el cliente se ha identificados
    """
    bloop_client = True
    while bloop_client:
        try:
            timeout_countdown = Timer(time_expire, client_timeout, (client, client_ip_and_port))
            timeout_countdown.start()
            response = getattr(client, 'socket').recv(buffer_size)

            if(not (len(response.decode().strip()) > 0)):
                valid_message = 'Command not found, please use a valid command\n'
                valid_message += CommandsChat.menu()
                getattr(client, 'socket').sendall(valid_message.encode())

            else:
                command = response.decode().split()
                timeout_countdown.cancel()

                if (command[0] == CommandsChat.DISCONNECT.name):
                    connected_clients.remove(client)
                    client_exit(client_ip_and_port)
                    CommandsMethods.disconnect(client)
                    bloop_client = False

                elif((command[0] == CommandsChat.IDENTIFY.name) and (not has_identified)):
                    has_identified = CommandsMethods.identify(client, command)

                else:
                    if(not has_identified):
                        message = 'TE DEBES IDENTIFICAR PRIMERO'
                        getattr(client, 'socket').sendall(message.encode())

                    else:
                        if (command[0] == CommandsChat.STATUS.name):
                            CommandsMethods.status(client, command)

                        elif((command[0] == CommandsChat.IDENTIFY.name) and has_identified):
                            message = 'YA TE HAS IDENTIFICADO\n'
                            getattr(client, 'socket').sendall(message.encode())

                        elif (command[0] == CommandsChat.USERS.name):
                            CommandsMethods.users(client)

                        elif (command[0] == CommandsChat.MESSAGE.name):
                            CommandsMethods.message(client, command)

                        elif (command[0] == CommandsChat.PUBLICMESSAGE.name):
                            CommandsMethods.public_message(client, command)

                        elif (command[0] == CommandsChat.CREATEROOM.name):
                            CommandsMethods.create_chat_room(client, command)

                        elif (command[0] == CommandsChat.INVITE.name):
                            CommandsMethods.invite(client, command)

                        elif (command[0] == CommandsChat.JOINROOM.name):
                            CommandsMethods.join_room(client, command)

                        elif (command[0] == CommandsChat.ROOMESSAGE.name):
                            CommandsMethods.room_message(client, command)

                        else:
                            valid_message = 'Command not found, please use a valid command\n'
                            valid_message += CommandsChat.menu()
                            getattr(client, 'socket').sendall(valid_message.encode())

        except:
            bloop_client = False
            getattr(client, 'socket').close()


def handle_client(client_sock, client_ip_and_port):
    """
    Método que maneja al cliente en el hilo

    :param client_sock: El socket del cliente
    :param client_ip_and_port: La IP y Puerto del cliente
    """
    client_ip = client_ip_and_port[0]
    client_port = int(client_ip_and_port[1])
    client_object = User.make_user(client_sock)
    connected_clients.append(client_object)
    has_identified = False
    prompt_commands(client_object, client_ip_and_port,client_sock, has_identified)

def end_server():
    if(len(connected_clients) < 0):
        for client in connected_clients:
            message = 'Servidor a terminado\n'
            getattr(client, 'socket').sendall(message.encode())
            CommandsMethods.disconnect(client)

def main():
    """
    Método main del servidor
    """
    server_port = 1234
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((host,server_port))
    sock.listen(backlog)
    print ('Servidor corriendo en puerto ' + str(server_port))
    logging.info("El servidor del chat está corriendo en el puerto {}".format(server_port))
    stdout.flush()

    try:
        bloop_connection = True
        while bloop_connection:
            client_connection, addr = sock.accept()
            print ('Cliente se conectó en '  + str(addr[0]) + ':' + str(addr[1]))
            logging.info("Cliente se conectó en la IP {} & Puerto {}".format( str(addr[0]), str(addr[1])))
            stdout.flush()
            thread = Thread(target=handle_client, args=(client_connection, addr))
            thread.daemon = True
            thread.start()
    except (KeyboardInterrupt, SystemExit):
        bloop_connection = False
        stdout.flush()
        end_server()
        print ('\nServidor terminado.')
        sys.exit(-1)

if __name__ == '__main__':
    main()
