#!/usr/bin/env python
# -*- coding: utf-8 -*-

from tkinter import *
from Tasks import TkRepeatingTask
from Tasks import BackgroundTask
import Client
from tkinter import ttk, font
from tkinter import scrolledtext as st
import time
import sys

# Gestor de geometría (place)
"""
Módulo que contien los métodos del cliente para la interfaz

"""
class Aplicacion():
     # Declara una variable de clase para contar ventanas

    ventana = 0

    # Declara una variable de clase para usar en el
    # cálculo de la posición de una ventana

    posx_y = 0

    def __init__(self):
        self.raiz = Tk()

        # Define la dimensión de la ventana

        self.raiz.geometry("700x550")

        # Establece que no se pueda cambiar el tamaño de la
        # ventana

        self.raiz.resizable(0,0)
        self.raiz.title("Chat Principal")
        self.fuente = font.Font(weight='bold')
        self.scrolledtext1=st.ScrolledText(self.raiz, width=50, height=25)
        self.scrolledtext1.place(x=10, y=10)

        self.mensaje = StringVar()
        self.mensajeEnviado = ttk.Entry(self.raiz, textvariable=self.mensaje, width=32)
        self.mensajeEnviado.place(x=10, y=420)
        self.botonEnviar = ttk.Button(self.raiz, text="Enviar Mensaje", command=self.publicRoom)
        self.botonEnviar.place(x=270, y=418)

        scrollbar = Scrollbar(self.raiz)
        scrollbar.place(x=440,y=10)

        self.mylist = Listbox(self.raiz, width=25, height=15)

        self.mylist.place( x= 440, y=10)
        scrollbar.config(command = self.mylist.yview)

        mensaje_sala = "Ingrese el nombre de la sala privada \n o el nombre del usuario \n para usar las opciones listadas."

        self.labelRoom = ttk.Label(self.raiz, text= mensaje_sala)
        self.labelRoom.place(x=440, y=260)

        self.estatus_chat = StringVar()
        self.estatusChat = ttk.Label(self.raiz, textvariable=self.estatus_chat)
        self.estatusChat.place(x=10, y=460)

        self.idRoom = StringVar()
        self.salaTexto = ttk.Entry(self.raiz, textvariable=self.idRoom, width=25)
        self.salaTexto.place(x=440, y=310)

        self.btnCrearSala = ttk.Button(self.raiz, text="Crear sala privada", command=self.createRoom)
        self.btnCrearSala.place(x=440, y=340)

        self.btnUnirseSala = ttk.Button(self.raiz, text="Unirse a sala privada", command=self.joinRoom)
        self.btnUnirseSala.place(x=440, y=370)

        self.btnInvitarSala = ttk.Button(self.raiz, text="Invitar a sala privada", command=self.inviteRoom)
        self.btnInvitarSala.place(x=440, y=400)

        self.btnMsjPrivado = ttk.Button(self.raiz, text="Mensaje Privado", command=self.privateRoom)
        self.btnMsjPrivado.place(x=440, y=430)

        self.btnDesconectar = ttk.Button(self.raiz, text="Desconectarse", command=self.disconnect)
        self.btnDesconectar.place(x=440, y=460)

        # El método 'bind()' asocia el evento de 'hacer clic
        # con el botón izquierdo del ratón en la caja de entrada
        # de la contraseña' expresado con '<button-1>' con el
        # método 'self.borrar_mensa' que borra el mensaje y la
        # contraseña y devuelve el foco al mismo control.
        # Otros ejemplos de acciones que se pueden capturar:
        # <double-button-1>, <buttonrelease-1>, <enter>, <leave>,
        # <focusin>, <focusout>, <return>, <shift-up>, <key-f10>,
        # <key-space>, <key-print>, <keypress-h>, etc.
        self.abrir_chat()
        #self.ctext2.bind('<Button-1>', self.borrar_mensa)
        self.raiz.mainloop()

    # Declara método para validar la contraseña y mostrar
    # un mensaje en la propia ventana, utilizando la etiqueta
    # 'self.mensa'. Cuando la contraseña es correcta se
    # asigna el color azul a la etiqueta 'self.etiq3' y
    # cuando es incorrecta el color rojo. Para ello. se emplea
    # el método 'configure()' que permite cambiar los valores
    # de las opciones de los widgets.

    def salir(self):
        self.bgTask.stop()
        self.timer.stop()
        self.dialogo.destroy()
        self.raiz.destroy()

    def disconnect(self):
        codigo = Client.send_to_server(self.cliente_socket, "DISCONNECT")
        if(codigo == 1):
            self.salir()

    def room_Message(self, room):
        message_room = self.msj_chat_room.get()
        codigo = Client.send_to_server(self.cliente_socket, "ROOMESSAGE "+ str(room) +" "+str(message_room))
        if(codigo==1):
            self.st_chat_room.insert(END, self.user +" : " +message_room + " \n")
            self.msj_chat_room.set("")

    def private_Message(self, user):
        message_user = self.msj_chat_private.get()
        codigo = Client.send_to_server(self.cliente_socket, "MESSAGE "+ str(user) +" "+str(message_user))
        if(codigo==1):
            self.st_chat_private.insert(END, self.user +" : " +message_user+ " \n")
            self.msj_chat_private.set("")

    def publicRoom(self):
        publicMessage = self.mensaje.get()
        codigo = Client.send_to_server(self.cliente_socket, "PUBLICMESSAGE " + publicMessage)
        if(codigo==1):
            self.scrolledtext1.insert(END, self.user +" : " +publicMessage + " \n")
            self.mensaje.set("")
        else:
            self.estatus_chat.set("Error al enviar mensaje al servidor")

    def privateRoom(self):
        user = self.idRoom.get()
        self.chat_user(user)

    def createRoom(self):
        self.room = self.idRoom.get()
        codigo = Client.send_to_server(self.cliente_socket, "CREATEROOM " + self.room)
        if(codigo==0):
            self.estatus_chat.set("Error al enviar mensaje al servidor")

    def joinRoom(self):
        self.room = self.idRoom.get()
        codigo = Client.send_to_server(self.cliente_socket, "JOINROOM " + self.room)
        if(codigo==0):
             self.estatus_chat.set("Error al enviar mensaje al servidor")

    def inviteRoom(self):
        room = self.idRoom.get()
        codigo = Client.send_to_server(self.cliente_socket, "INVITE " + room)
        if(codigo==0):
            self.estatus_chat.set("Error al enviar mensaje al servidor")

    def ConsultarUsuarios(self):
            self.mylist.delete(0,END)
            cod_users, msj_users = Client.send_to_server(self.cliente_socket, "USERS")

    def MensajesServer(self, isRunningFunc=None ):
        while True:
            codigo, mensaje = Client.response_Server(self.cliente_socket)
            if(codigo==1):
                array_msg = mensaje.split("_")
                cod_msg = int(array_msg[0])
                msg= str(array_msg[1])
                if(cod_msg==101):
                    self.mensajeRecibido= msg
                if(cod_msg==102):
                    self.usuarioIdentificado = True
                    self.actualizarInterfaz(msg)
                    self.timer2.start()
                if(cod_msg==103):
                    self.actualizarInterfaz(msg)
                if(cod_msg==104):
                    self.actualizarInterfaz(msg)
                if(cod_msg==105):
                    self.mylist.delete(0,END)
                    users = msg.split()
                    for user in users:
                        self.mylist.insert(END, user)
                if(cod_msg==106):
                    self.st_chat_private.insert(END, msg + " \n")
                if(cod_msg==107):
                    self.actualizarInterfaz(msg)
                if(cod_msg==108):
                    self.actualizarInterfaz(msg)
                if(cod_msg==109):
                    self.scrolledtext1.insert(END, msg + " \n")
                if(cod_msg==110):
                    self.actualizarInterfaz(msg)
                if(cod_msg==111):
                    self.actualizarInterfaz(msg)
                if(cod_msg==112):
                    self.actualizarInterfaz(msg)
                    self.chat_privado(self.room)
                if(cod_msg==113):
                    self.actualizarInterfaz(msg)
                if(cod_msg==114):
                    self.actualizarInterfaz(msg)
                if(cod_msg==115):
                    self.actualizarInterfaz(msg)
                if(cod_msg==116):
                    self.actualizarInterfaz(msg)
                if(cod_msg==117):
                    self.actualizarInterfaz(msg)
                if(cod_msg==118):
                    self.actualizarInterfaz(msg)
                    self.chat_privado(self.room)
                if(cod_msg==119):
                    self.actualizarInterfaz(msg)
                if(cod_msg==120):
                    self.actualizarInterfaz(msg)
                if(cod_msg==121):
                    self.st_chat_room.insert(END, msg + " \n")
                if(cod_msg==122):
                    self.actualizarInterfaz(msg)
                if(cod_msg==123):
                    self.actualizarInterfaz(msg)
                if(cod_msg==124):
                    self.actualizarInterfaz(msg)

    def consultarUsuarios(self):
        cod_resp = Client.send_to_server(self.cliente_socket, "USERS")

    def validarUsuario(self):
        try:
            if(self.usuarioIdentificado==True):
                self.dialogo.destroy()
                self.raiz.update()
                self.raiz.deiconify()
                self.timer.stop()
            else:
                self.etiq4.configure(foreground='red')
                self.mensa.set(self.mensajeRecibido)
        except Exception as ex:
            sys.exit(-1)

    def actualizarInterfaz(self, status):
            self.estatus_chat.set(str(status))

    def aceptar(self):
        self.user = self.usuario.get()
        puerto = self.puerto.get()
        ip = self.ip.get()
        if self.user:
            codigo,socket,mensaje = Client.client_chat(ip, puerto)
            if(codigo==0):
                self.etiq4.configure(foreground='red')
                self.mensa.set(mensaje)
            if(codigo==1):
                self.cliente_socket = socket
                self.usuarioIdentificado = False
                self.mensajeRecibido = ""
                self.bgTask = BackgroundTask(self.MensajesServer)
                self.bgTask.start()
                self.timer = TkRepeatingTask(self.raiz, self.validarUsuario, 1)
                self.timer.start()
                codigo = Client.send_to_server(self.cliente_socket, "IDENTIFY " + self.user)
                self.timer2 = TkRepeatingTask(self.raiz, self.consultarUsuarios, 5000)
        else:
            self.etiq3.configure(foreground='red')
            self.mensa.set("Ingrese su nombre de usuario")

    # Declara un método para borrar el mensaje anterior y
    # la caja de entrada de la contraseña

    def borrar_mensa(self, evento):
        self.clave.set("")
        self.mensa.set("")

    def chat_privado(self, room):
        self.chat_room = Toplevel()
        self.chat_room.geometry("640x480")

        self.chat_room.resizable(0,0)
        self.chat_room.title("Sala Privada: "+room)
        self.st_chat_room=st.ScrolledText(self.chat_room, width=50, height=25)
        self.st_chat_room.place(x=10, y=10)

        self.msj_chat_room = StringVar()
        self.txt_chat_room = ttk.Entry(self.chat_room, textvariable=self.msj_chat_room, width=52)
        self.txt_chat_room.place(x=10, y=420)
        self.btn_chat_room = ttk.Button(self.chat_room, text="Enviar Mensaje", command= lambda:self.room_Message(room))
        self.btn_chat_room.place(x=330, y=418)
        self.raiz.wait_window(self.chat_room)

    def chat_user(self, user):
        self.chat_private = Toplevel()
        self.chat_private.geometry("640x480")

        self.chat_private.resizable(0,0)
        self.chat_private.title("Chat con "+user)
        self.st_chat_private=st.ScrolledText(self.chat_private, width=50, height=25)
        self.st_chat_private.place(x=10, y=10)

        self.msj_chat_private = StringVar()
        self.txt_chat_private = ttk.Entry(self.chat_private, textvariable=self.msj_chat_private, width=52)
        self.txt_chat_private.place(x=10, y=420)
        self.btn_chat_private = ttk.Button(self.chat_private, text="Enviar Mensaje", command= lambda:self.private_Message(user))
        self.btn_chat_private.place(x=330, y=418)
        self.raiz.wait_window(self.chat_private)

    def abrir_chat(self):
        self.raiz.withdraw()
        self.dialogo = Toplevel()

         # Define la dimensión de la ventana

        self.dialogo.geometry("450x180")

        # Establece que no se pueda cambiar el tamaño de la
        # ventana

        self.dialogo.resizable(0,0)
        self.dialogo.title("INICIO DE SESION")
        self.fuente = font.Font(weight='bold')
        self.etiq1 = ttk.Label(self.dialogo, text="Puerto:", font=self.fuente)
        self.etiq2 = ttk.Label(self.dialogo, text="IP:", font=self.fuente)
        self.etiq3 = ttk.Label(self.dialogo, text="Usuario:", font=self.fuente)

        # Declara una variable de cadena que se asigna a
        # la opción 'textvariable' de un widget 'Label' para
        # mostrar mensajes en la ventana. Se asigna el color
        # azul a la opción 'foreground' para el mensaje.

        self.mensa = StringVar()
        self.etiq4 = ttk.Label(self.dialogo, textvariable=self.mensa, font=self.fuente, foreground='blue')

        self.ip = StringVar()
        self.puerto = StringVar()
        self.usuario = StringVar()
        self.ctext1 = ttk.Entry(self.dialogo, textvariable=self.puerto, width=30)
        self.ctext2 = ttk.Entry(self.dialogo, textvariable=self.ip, width=30)
        self.ctext3 = ttk.Entry(self.dialogo, textvariable=self.usuario, width=30)
        self.separ1 = ttk.Separator(self.dialogo, orient=HORIZONTAL)
        self.boton1 = ttk.Button(self.dialogo, text="Entrar", padding=(5,5), command=self.aceptar)
        self.boton2 = ttk.Button(self.dialogo, text="Regisrarse", padding=(5,5), command=self.salir)


        # Se definen las ubicaciones de los widgets en la
        # ventana asignando los valores de las opciones 'x' e 'y'
        # en píxeles.

        self.etiq1.place(x=30, y=10)
        self.etiq2.place(x=30, y=40)
        self.etiq3.place(x=30, y=70)
        self.etiq4.place(x=30, y=150)
        self.ctext1.place(x=150, y=10)
        self.ctext2.place(x=150, y=40)
        self.ctext3.place(x=150, y=70)
        self.separ1.place(x=5, y=145, bordermode=OUTSIDE,height=10, width=420)
        self.boton1.place(x=150, y=100)
        self.boton2.place(x=250, y=100)

        # Cuando la ejecución del programa llega a este
        # punto se utiliza el método wait_window() para
        # esperar que la ventana 'self.dialogo' sea
        # destruida.
        # Mientras tanto se atiende a los eventos locales
        # que se produzcan, por lo que otras partes de la
        # aplicación seguirán funcionando con normalidad.
        # Si hay código después de esta línea se ejecutará
        # cuando la ventana 'self.dialogo' sea cerrada.
        self.raiz.wait_window(self.dialogo)

def main():
    mi_app = Aplicacion()
    return 0

if __name__ == '__main__':
    main()
