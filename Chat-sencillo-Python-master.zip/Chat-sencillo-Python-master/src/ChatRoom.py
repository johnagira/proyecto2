import ChatRoom

"""
Clase ChatRoom

"""
class ChatRoom:
    """
    La clase ChatRoom crea objetos para los eventos de cuarto de chat
    """
    def __init__(self, name, owner, invited, joined):
        """
        Construye un objeto de tipo "ChatRoom".

        :param owner: El nombre con el que se identificó el cliente
        :param name: El socket donde se guarda la conexión
        :param invited: El estado que puede ser activo, ocupado o lejos
        :param joined:
        """
        self.owner = owner
        self.name = name
        self.invited = invited
        self.joined = joined

    def create_room(name, owner):
        """
        Crea un objeto de tipo ChatRoom inicializado
        :param name: El nombre del ChatRoom
        :return: regresa un objeto tipo ChatRoom
        """
        chat_name = name
        chat_owner = owner
        invited = []
        joined = [owner]
        chat_room = ChatRoom(chat_name, chat_owner, invited, joined)
        return chat_room
