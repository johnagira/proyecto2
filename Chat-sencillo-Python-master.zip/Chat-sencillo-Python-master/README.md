# proyecto1
Proyecto 1 Modelado y Programación: "Chat"

Información del proyecto escrita en el archivo proyecto1.pdf, el código latex se encuentra en la carpte src.
