#!/bin/bash
COMANDO=$1
if [ $COMANDO == 'server' ]
then
  python3 src/Server.py
fi

if [ $COMANDO == 'client' ]
then
  python3 src/Interfaz.py
fi

if [ $COMANDO == 'terminal' ]
then
  python3 src/ClientTerminal.py
fi

if [ $COMANDO == 'test' ]
then
  cd src/tests
  python3 TestServer.py
fi

if [ $COMANDO == 'doc' ]
then
  mkdir -p doc
  mkdir -p doc/pyc
  cd src
  pydoc -w ChatRoom
  pydoc -w Client
  pydoc -w CommandsChat
  pydoc -w CommandsMethods
  pydoc -w Server
  pydoc -w User
  pydoc -w ClientTerminal
  pydoc -w Tasks
  mv *.html ../doc
  mv *.pyc ../doc/pyc
fi

if [ $COMANDO == 'clean' ]
then
	rm -r doc
  rm -r chatserver.log
  cd src
  rm -r __pycache__
fi
